#import <Flutter/Flutter.h>

@interface TelephonyPlugin : NSObject<FlutterPlugin>
@end
